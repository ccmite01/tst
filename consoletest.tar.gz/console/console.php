<?php

   session_start();
   if(!isset($_SESSION["user_name"])) {
       $no_login_url = "index.php";
       header("Location: {$no_login_url}");
       exit;
   }

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <!--
            @Su.Py~#_
        -->
        <meta charset="utf-8">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>検証Webコンソール - <?=$_SESSION["user_name"]?></title>
        <link rel="stylesheet" media="screen, projection" href="/console/css/core.css" />
        <link rel="stylesheet" media="screen, projection" href="/console/css/font-awesome.css" />
        <link rel="stylesheet" media="screen, projection" href="/console/css/notification.css" />
        <script src="js/jQuery.min.js"></script>
        <script language="javascript" src="js/jquery.timers-1.0.0.js"></script>
        <script language="javascript" src="js/notification.js"></script>

        <script type="text/javascript">
        $(document).ready(function() {
        	  var status = "";
        	  var lld = "";
        	  var togglecmdi = 1;

            notify("<i class='fa fa-info-circle'></i> <div class='notification-content'> <div class='notification-header'>ヒント</div> サーバーステータス (右上の角) をクリックするとステータスを更新できます。</div>");
            notify("<i class='fa fa-info-circle'></i> <div class='notification-content'> <div class='notification-header'>ヒント</div> コマンドの入力を開始するとすぐに入力欄が表示されます。</div>");

        	  gh();

            function gh() {
                checklogs();
              	lld = "";
              	status = "gh";
              	$.post("reqman.php", {status: status, lld: lld}, function(clgh) {
              	    $("#console").html(clgh);
              			notify("<i class='fa fa-check-circle notification-success'></i> <div class='notification-content'> <div class='notification-header notification-success'>成功</div> ログデータを正常に取得しました。</div>");
              		  sd();
              		  status = "lld";
              		  $.post("reqman.php", {status: status, lld: lld}, function(cllld) {
              			    lld = cllld;
              		  });
              		  status = "ilu";
              		  $.post("reqman.php", {status: status, lld: lld}, function(clilu) {
              			    $("#infologs").html(clilu);
              		  });
              	});
              	setInterval(update, 1000);
        	  }
        	  function checklogs() {
                logstatus = "check";
              	$.post("lpc.php", {logstatus: logstatus}, function(lsd) {
              		  if (lsd !== "-rw-rw-rw-") {
              			    notify("<i class='fa fa-times-circle notification-error'></i> <div class='notification-content'> <div class='notification-header notification-error'>エラー</div> ログデータを取得できませんでした。 サーバーディレクトリ/logs/latest.logのオーナーをwww-dataに変更するか、パーミッションを666に変更してください。</div>");
              			    logstatus = "update";
              			    $.post("lpc.php", {logstatus: logstatus}, function(lpcd) {
              			        if (lpcd == "-rw-rw-rw-") {
              				          notify("<i class='fa fa-check-circle notification-success'></i> <div class='notification-content'> <div class='notification-header notification-success'>成功</div> サーバーディレクトリ/logs/latest.logのパーミッションを666に変更しました。 ログを更新しています...</div>");
              					        gh();
              				      } else {
              					        notify("<i class='fa fa-times-circle notification-error'></i> <div class='notification-content'> <div class='notification-header notification-error'>エラー</div> サーバーディレクトリ/logs/latest.logのパーミッションを666に変更できませんでした。</div>");
              				      }
              		      });
              	    }
              	});
        	  }

        	  function update() {
        	      status = "lld";
        	      $.post("reqman.php", {status: status, lld: lld}, function(lldrdata) {
                    console.log(lldrdata)
            			  if (lldrdata == "error.logPermissionInvalid") {
            				    checklogs();
            				    return false;
            			  }
            		    if (lldrdata !== lld) {
            			      status = "clu";
            			      $.post("reqman.php", {status: status, lld: lld}, function(clurdata) {
            				        $("#console").append(clurdata);
                            sd();
            					      status = "ilu";
            	 	            $.post("reqman.php", {status: status, lld: lld}, function(clilu) {
                             	    $("#infologs").html(clilu);
                            });
            			      });
            				    lld = lldrdata;
            		    }
        	      });
        	  }

            function sd() {
                $('html, body').animate({ scrollTop: $('#sd').offset().top }, 'slow');
            }

            $(document).on('keydown', function(e) {
            	  var key = e.keyCode || e.charCode;
                if(key == 13) {
                	  // ENTER
                		var cmd = $("#cmd-input").val();
                		cmdtype = $(".cmd-type").html();
                		cmdtype = cmdtype.replace("/", "");

                		cmd = cmdtype + cmd;
                    $.post("exec.php", {cmd: cmd}, function(cmdrd) {
                			  $(".cmd-input").addClass("hidden");
                			  $("#cmd-input").val("");
                			  $(".cmd-type").html("");
                			  togglecmdi = 1;
                			  notify(cmdrd);
                		});
                } else if(key == 27) {
                		// ESC
                		$(".cmd-input").addClass("hidden");
                	  $("#cmd-input").val("");
                		$(".cmd-type").html("");
                		togglecmdi = 1;
            	  } else if(key == 8) {
                		// BACKSPACE
                		if (document.getElementById('cmd-input').value.length == 0) {
                			   $(".cmd-input").addClass("hidden");
                			   $("#cmd-input").val("");
                			   $(".cmd-type").html("");
                		     togglecmdi = 1;
                		 }
            	  } else {
            	      $(".cmd-input").removeClass("hidden");
            		    $("#cmd-input").focus();
                	  if(key == 191) {
                  	    //  /<command>
                  			e.preventDefault();
                  		  if (togglecmdi == 1) {
                  		      $(".cmd-type").html("/");
                  				  togglecmdi = 0;
                  				  return false;
                  	    }
                  	} else if (togglecmdi == 1) {
                  	    //  /say <message>
                  		  $(".cmd-type").html("/say ");
                  	}
                  	togglecmdi = 0;
            	  }
            });

            $(".server-status").click(function() {
                ss();
            });
            ss();

            function ss() {
                $.post("ss.php", function(ssd) {
                
                    if (ssd == "online") {
                        ssdd = "オンライン";
                    } else {
										    ssdd = "オフライン";
										}
										
                    $(".server-status").html("検証サーバーは " + ssdd).addClass("server-status-" + ssd);
            		    if (ssd == "online") {
            			      $(".server-status").removeClass("server-status-offline");
            		    } else {
            			      $(".server-status").removeClass("server-status-online");
            		    }
                });
            }

            function notify(content) {
                $.createNotification({
            	      content: content,
            	      duration: 10000
                });
            }
        });
        </script>
        <meta name="msapplication-square70x70logo" content="/console/img/site-tile-70x70.png">
        <meta name="msapplication-square150x150logo" content="/console/img/site-tile-150x150.png">
        <meta name="msapplication-wide310x150logo" content="/console/img/site-tile-310x150.png">
        <meta name="msapplication-square310x310logo" content="/console/img/site-tile-310x310.png">
        <meta name="msapplication-TileColor" content="#0078d7">
        <link rel="shortcut icon" type="image/vnd.microsoft.icon" href="/console/img/favicon.ico">
        <link rel="icon" type="image/vnd.microsoft.icon" href="/console/img/favicon.ico">
        <link rel="apple-touch-icon" sizes="57x57" href="/console/img/apple-touch-icon-57x57.png">
        <link rel="apple-touch-icon" sizes="60x60" href="/console/img/apple-touch-icon-60x60.png">
        <link rel="apple-touch-icon" sizes="72x72" href="/console/img/apple-touch-icon-72x72.png">
        <link rel="apple-touch-icon" sizes="76x76" href="/console/img/apple-touch-icon-76x76.png">
        <link rel="apple-touch-icon" sizes="114x114" href="/console/img/apple-touch-icon-114x114.png">
        <link rel="apple-touch-icon" sizes="120x120" href="/console/img/apple-touch-icon-120x120.png">
        <link rel="apple-touch-icon" sizes="144x144" href="/console/img/apple-touch-icon-144x144.png">
        <link rel="apple-touch-icon" sizes="152x152" href="/console/img/apple-touch-icon-152x152.png">
        <link rel="apple-touch-icon" sizes="180x180" href="/console/img/apple-touch-icon-180x180.png">
        <link rel="icon" type="image/png" sizes="36x36" href="/console/img/android-chrome-36x36.png">
        <link rel="icon" type="image/png" sizes="48x48" href="/console/img/android-chrome-48x48.png">
        <link rel="icon" type="image/png" sizes="72x72" href="/console/img/android-chrome-72x72.png">
        <link rel="icon" type="image/png" sizes="96x96" href="/console/img/android-chrome-96x96.png">
        <link rel="icon" type="image/png" sizes="128x128" href="/console/img/android-chrome-128x128.png">
        <link rel="icon" type="image/png" sizes="144x144" href="/console/img/android-chrome-144x144.png">
        <link rel="icon" type="image/png" sizes="152x152" href="/console/img/android-chrome-152x152.png">
        <link rel="icon" type="image/png" sizes="192x192" href="/console/img/android-chrome-192x192.png">
        <link rel="icon" type="image/png" sizes="256x256" href="/console/img/android-chrome-256x256.png">
        <link rel="icon" type="image/png" sizes="384x384" href="/console/img/android-chrome-384x384.png">
        <link rel="icon" type="image/png" sizes="512x512" href="/console/img/android-chrome-512x512.png">
        <link rel="icon" type="image/png" sizes="36x36" href="/console/img/icon-36x36.png">
        <link rel="icon" type="image/png" sizes="48x48" href="/console/img/icon-48x48.png">
        <link rel="icon" type="image/png" sizes="72x72" href="/console/img/icon-72x72.png">
        <link rel="icon" type="image/png" sizes="96x96" href="/console/img/icon-96x96.png">
        <link rel="icon" type="image/png" sizes="128x128" href="/console/img/icon-128x128.png">
        <link rel="icon" type="image/png" sizes="144x144" href="/console/img/icon-144x144.png">
        <link rel="icon" type="image/png" sizes="152x152" href="/console/img/icon-152x152.png">
        <link rel="icon" type="image/png" sizes="160x160" href="/console/img/icon-160x160.png">
        <link rel="icon" type="image/png" sizes="192x192" href="/console/img/icon-192x192.png">
        <link rel="icon" type="image/png" sizes="196x196" href="/console/img/icon-196x196.png">
        <link rel="icon" type="image/png" sizes="256x256" href="/console/img/icon-256x256.png">
        <link rel="icon" type="image/png" sizes="384x384" href="/console/img/icon-384x384.png">
        <link rel="icon" type="image/png" sizes="512x512" href="/console/img/icon-512x512.png">
        <link rel="icon" type="image/png" sizes="16x16" href="/console/img/icon-16x16.png">
        <link rel="icon" type="image/png" sizes="24x24" href="/console/img/icon-24x24.png">
        <link rel="icon" type="image/png" sizes="32x32" href="/console/img/icon-32x32.png">
        <link rel="manifest" href="/console/img/manifest.json">
    </head>
    <body>
    
    <div class="update" id="console"></div>
    <div id="sd"></div>

    <a href=./list.php><div id="infologs"></div></a>
    <div class="cmd-input hidden">
        <div class="cmd-wrapper">
            <div class="cmd-type"></div>
            <input type="text" id="cmd-input" placeholder="コマンドを入力してください... エンターキーで実行." />
    	</div>
    </div>
    
    
    <div class="server-status"></div>
    <div class="notification-board right top"></div>

    </body>
</html>
