<?php
  session_start();
  $error_message = "";
  if(isset($_POST["login"])) {
      if($_POST["user_name"] == "admin" && $_POST["password"] == "ccadmin") {
          $_SESSION["user_name"] = $_POST["user_name"];
          $login_success_url = "console.php";
          header("Location: {$login_success_url}");
          exit;
      }
      
  $error_message = "<font  face=\"ＭＳ 明朝\" size=10 color=red>攻撃を検知！</font> ";
  $error_message2 = "<li><font  face=\"ＭＳ 明朝\" size=10>発信元をトレース... IPアドレス...</font> <font  face=\"ＭＳ 明朝\" size=10 color=red>";
  $error_message3 = "</font><li><font  face=\"ＭＳ 明朝\" size=10>攻性防壁を起動中... 対象ユーザ名...</font> <font  face=\"ＭＳ 明朝\" size=10 color=red>";
  $error_message4 = "</font>";
  }
?>

<?php
  if($error_message) {
        echo $error_message;
        echo $error_message2;
        echo $_SERVER["REMOTE_ADDR"];
        echo $error_message3;
        echo $_SESSION["user_name"];
        echo $error_message4;
  }
?>

<html>
<head>

        <meta charset="utf-8">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>管理区域 - <?=$_SESSION["user_name"]?></title>
        <link rel="stylesheet" media="screen, projection" href="/console/css/core.css" />
        <link rel="stylesheet" media="screen, projection" href="/console/css/font-awesome.css" />
        <link rel="stylesheet" media="screen, projection" href="/console/css/notification.css" />
        <meta name="msapplication-square70x70logo" content="/console/img/site-tile-70x70.png">
        <meta name="msapplication-square150x150logo" content="/console/img/site-tile-150x150.png">
        <meta name="msapplication-wide310x150logo" content="/console/img/site-tile-310x150.png">
        <meta name="msapplication-square310x310logo" content="/console/img/site-tile-310x310.png">
        <meta name="msapplication-TileColor" content="#0078d7">
        <link rel="shortcut icon" type="image/vnd.microsoft.icon" href="/console/img/favicon.ico">
        <link rel="icon" type="image/vnd.microsoft.icon" href="/console/img/favicon.ico">
        <link rel="apple-touch-icon" sizes="57x57" href="/console/img/apple-touch-icon-57x57.png">
        <link rel="apple-touch-icon" sizes="60x60" href="/console/img/apple-touch-icon-60x60.png">
        <link rel="apple-touch-icon" sizes="72x72" href="/console/img/apple-touch-icon-72x72.png">
        <link rel="apple-touch-icon" sizes="76x76" href="/console/img/apple-touch-icon-76x76.png">
        <link rel="apple-touch-icon" sizes="114x114" href="/console/img/apple-touch-icon-114x114.png">
        <link rel="apple-touch-icon" sizes="120x120" href="/console/img/apple-touch-icon-120x120.png">
        <link rel="apple-touch-icon" sizes="144x144" href="/console/img/apple-touch-icon-144x144.png">
        <link rel="apple-touch-icon" sizes="152x152" href="/console/img/apple-touch-icon-152x152.png">
        <link rel="apple-touch-icon" sizes="180x180" href="/console/img/apple-touch-icon-180x180.png">
        <link rel="icon" type="image/png" sizes="36x36" href="/console/img/android-chrome-36x36.png">
        <link rel="icon" type="image/png" sizes="48x48" href="/console/img/android-chrome-48x48.png">
        <link rel="icon" type="image/png" sizes="72x72" href="/console/img/android-chrome-72x72.png">
        <link rel="icon" type="image/png" sizes="96x96" href="/console/img/android-chrome-96x96.png">
        <link rel="icon" type="image/png" sizes="128x128" href="/console/img/android-chrome-128x128.png">
        <link rel="icon" type="image/png" sizes="144x144" href="/console/img/android-chrome-144x144.png">
        <link rel="icon" type="image/png" sizes="152x152" href="/console/img/android-chrome-152x152.png">
        <link rel="icon" type="image/png" sizes="192x192" href="/console/img/android-chrome-192x192.png">
        <link rel="icon" type="image/png" sizes="256x256" href="/console/img/android-chrome-256x256.png">
        <link rel="icon" type="image/png" sizes="384x384" href="/console/img/android-chrome-384x384.png">
        <link rel="icon" type="image/png" sizes="512x512" href="/console/img/android-chrome-512x512.png">
        <link rel="icon" type="image/png" sizes="36x36" href="/console/img/icon-36x36.png">
        <link rel="icon" type="image/png" sizes="48x48" href="/console/img/icon-48x48.png">
        <link rel="icon" type="image/png" sizes="72x72" href="/console/img/icon-72x72.png">
        <link rel="icon" type="image/png" sizes="96x96" href="/console/img/icon-96x96.png">
        <link rel="icon" type="image/png" sizes="128x128" href="/console/img/icon-128x128.png">
        <link rel="icon" type="image/png" sizes="144x144" href="/console/img/icon-144x144.png">
        <link rel="icon" type="image/png" sizes="152x152" href="/console/img/icon-152x152.png">
        <link rel="icon" type="image/png" sizes="160x160" href="/console/img/icon-160x160.png">
        <link rel="icon" type="image/png" sizes="192x192" href="/console/img/icon-192x192.png">
        <link rel="icon" type="image/png" sizes="196x196" href="/console/img/icon-196x196.png">
        <link rel="icon" type="image/png" sizes="256x256" href="/console/img/icon-256x256.png">
        <link rel="icon" type="image/png" sizes="384x384" href="/console/img/icon-384x384.png">
        <link rel="icon" type="image/png" sizes="512x512" href="/console/img/icon-512x512.png">
        <link rel="icon" type="image/png" sizes="16x16" href="/console/img/icon-16x16.png">
        <link rel="icon" type="image/png" sizes="24x24" href="/console/img/icon-24x24.png">
        <link rel="icon" type="image/png" sizes="32x32" href="/console/img/icon-32x32.png">
        <link rel="manifest" href="/console/img/manifest.json">
</head>
<body>

<div class="log info">新規ユーザー登録</div>

<div class="log"></div>
<div class="log"></div>
<div class="log"></div>
<div class="log"></div>

<div class="log info">
<form action="index.php" method="POST">
  <p><input type="text" name="user_name"></p>
  <p><input type="password" name="password"></p>
  <input type="submit" name="login" value="登録">
</form>
</div>


</body>
</html>
