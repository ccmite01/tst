﻿<?php

if(isset($_POST['cmd'])) {
    $cmd = $_POST['cmd'];
    if ($cmd) {
		    include("config/config.php");
		    include("class/eventLogger.class.php");
        $elog = new eventLogger();

        $ss = shell_exec("ss -tulpn | grep :25585");
        if ($cmd == "start") {
			      $elog->elog("start コマンドを受信.");
            if (!$ss) {
		            file_put_contents(SERVER_LOG_DIR, "[" . date("h:i:s") . "] [SYSTM]: start コマンドを受信しました, サーバーを起動しています... \n", FILE_APPEND);
                # shell_exec("sudo screen -S mcs");
                #
                # Not working
                $cmd = "/start.sh";
                $output = shell_exec('$cmd');
                if($output) {
                    echo "<i class='fa fa-times-circle notification-error'></i> <div class='notification-content'> <div class='notification-header notification-error'>エラー</div> $output</div>";
                    $elog->elog("  └─ $output");
                } else {
                    echo "<i class='fa fa-check-circle notification-success'></i> <div class='notification-content'> <div class='notification-header notification-success'>成功</div> 正常にサーバーを起動しました.</div>";
                    $elog->elog("  └─ サーバーを正常に起動しました.");
                }

            } else {
                echo "<i class='fa fa-times-circle notification-error'></i> <div class='notification-content'> <div class='notification-header notification-error'>エラー</div> サーバーは既に起動しています.</div>";
                $elog->elog("  └─ Error: Server is already running.");
            }
        } else if ($cmd == "stop") {
	          $elog->elog("stop コマンドを受信.");
            if ($ss) {
                file_put_contents(SERVER_LOG_DIR, "[" . date("h:i:s") . "] [SYSTM]: stop コマンドを受信しました, サーバーを停止しています... \n", FILE_APPEND);
                $output = shell_exec('sudo screen -S mcs -p 0 -X stuff "' .$cmd. '\n";');
                if($output) {
                    echo "<i class='fa fa-times-circle notification-error'></i> <div class='notification-content'> <div class='notification-header notification-error'>エラー</div> $output</div>";
                    $elog->elog("  └─ $output");
                } else {
                    echo "<i class='fa fa-check-circle notification-success'></i> <div class='notification-content'> <div class='notification-header notification-success'>成功</div> 正常にサーバーを停止しました.</div>";
                    $elog->elog("  └─ サーバーを正常に停止しました.");
                }

            } else {
                echo "<i class='fa fa-times-circle notification-error'></i> <div class='notification-content'> <div class='notification-header notification-error'>エラー</div> サーバーが起動していません.</div>";
                $elog->elog("  └─ エラー: サーバーが起動していません..");
            }
        } else {
			      $elog->elog("サーバーコマンドを発行しました: $cmd");
            if ($ss) {

                $output = shell_exec('sudo screen -S mcs -p 0 -X stuff "' .$cmd. '\n";');
                if($output) {
                    echo "<i class='fa fa-times-circle notification-error'></i> <div class='notification-content'> <div class='notification-header notification-error'>エラー</div> $output</div>";
                    $elog->elog("  └─ $output");
                } else {
                    echo "<i class='fa fa-check-circle notification-success'></i> <div class='notification-content'> <div class='notification-header notification-success'>成功</div> 次のコマンドを実行しました: " . $cmd . "</div>";
                    $elog->elog("  └─ コマンドの実行に成功しました.");
                }

            } else {
                echo "<i class='fa fa-times-circle notification-error'></i> <div class='notification-content'> <div class='notification-header notification-error'>エラー</div> サーバーが実行されていません. 'start'コマンドで起動してください.</div>";
                $elog->elog("  └─ エラー: サーバーが起動していません.");
            }
        }
	} else {
	    echo "<i class='fa fa-times-circle notification-error'></i> <div class='notification-content'> <div class='notification-header notification-error'>Error</div> Error, command cant be left blank.</div>";
	}
}

?>
