<?php

define("SERVER_NAME", "ccmite");
define("SERVER_IP", "127.0.0.1");
define("SERVER_PORT", "25565");

define("SERVER_ROOT_DIR", "/opt/minecraft/test/");
define("SERVER_LOG_DIR", SERVER_ROOT_DIR . "logs/latest.log");

?>
