<?php

   session_start();
   if(!isset($_SESSION["user_name"])) {
       $no_login_url = "index.php";
       header("Location: {$no_login_url}");
       exit;
   }


  if(isset($_GET['ip'])) {
      $ip = $_GET['ip'];
  }

  $mtr = shell_exec("./mtr.sh $ip");

?>

<html>
<head>

        <meta charset="utf-8">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>MTR調査</title>
</head>
<body>

<pre><?=$mtr?></pre>

</body>
</html>







