#!/bin/bash
/usr/bin/mtr -b -w -c 3 $1
